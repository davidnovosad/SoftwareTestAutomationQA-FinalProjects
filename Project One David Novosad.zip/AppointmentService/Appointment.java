package Appointment;

import java.util.Date;

public class Appointment {
	
	private final String appointmentId; //setting to final as id cannot be updatable
	private Date date;
	private String description;
	
	public Appointment (String appointmentId, Date date, String description) {
		
		// checking the requirements for appointment ID
		if (appointmentId == null || appointmentId.length() > 10) {
			throw new IllegalArgumentException("Invalid appointmentId");
		}
		
		// checking the requirements for appointment date
		if (date == null || date.before(new Date())) {
			throw new IllegalArgumentException("Invalid date");
		}
		
		// checking the requirements for appointment description 
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid description");
		}
			
		this.appointmentId = appointmentId;
		this.date = date;
		this.description = description;
	}
	
	// Getter function for getting the appointment id		
	public String getAppointmentId () {
		return appointmentId;
	}
	
	// Getter function for getting the appointment date
	public Date getDate () {
		return date;
	}
	
	// Getter function for getting the appointment description
	public String getDescription () {
		return description;
	}
	
	// Setter function for setting the appointment date
	public void setDate(Date newDate) {
		date = newDate;
	}
	
	// Setter function for setting the appointment description
	public void setDescription(String newDescription) {
		description = newDescription;
	}

}