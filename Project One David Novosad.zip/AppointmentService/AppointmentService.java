package Appointment;

import java.util.HashMap;
import java.util.Date;

public class AppointmentService {
	//initializing new hash map for appointments
	private HashMap<String, Appointment> appointments;

	public AppointmentService() {
		appointments = new HashMap<>();
	}
	
	// function to add appointments with unique id
	public void addAppointment (Appointment appointment) {
		appointments.put(appointment.getAppointmentId(), appointment);
	}
	
	// function to delete appointment with id
	public void deleteAppointment (String appointmentId) {
		appointments.remove(appointmentId);
	}
	
	//function to update appointments info
	public void updateAppointment (String appointmentId, Date date, String description) {
		appointments.get(appointmentId).setDate(date);
		appointments.get(appointmentId).setDescription(description);
	}
	
	// function to get appointments inside the hashmap structure
	public HashMap<String, Appointment> getAppointments () {
		return appointments;
	}
}