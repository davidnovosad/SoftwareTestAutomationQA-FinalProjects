package Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import Appointment.Appointment;

public class AppointmentTest {

	@Test
	@DisplayName("Test of Getter functions")
	void testAppointment() {
		Date today = new Date();
		Appointment appointment = new Appointment("123456", today, "example description");
		assertTrue(appointment.getAppointmentId().equals("123456"));
		assertTrue(appointment.getDate().equals(today));
		assertTrue(appointment.getDescription().equals("example description"));
	}

	// Test if the appointment id is too long
	@Test
	@DisplayName("Appointment ID is too long")
	void testAppointmentIdTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("123456789101112", new Date(), "example description");
		});
	}

	// Test if the appointment id is null
	@Test
	@DisplayName("Appointment ID is null")
	void testAppointmentIdIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment(null, new Date(), "example description");
		});
	}

	// Test if the appointment date is in the past
	@Test
	@DisplayName("Appointment date is in the past")
	void testAppointmentDateInPast() throws ParseException {
		Date pastDate = new SimpleDateFormat("MMMM dd, yyyy").parse("April 30, 2002");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("123456", pastDate, "example description");
		});
	}

	// Test if the appointment date is null
	@Test
	@DisplayName("Appointment date is null")
	void testAppointmentDayIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("123456", null, "example description");
		});
	}

	// Test if the appointment description is too long
	@Test
	@DisplayName("Appointment description is too long")
	void testAppointmentDescriptionTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("123456", new Date(), "Example description is way too long and will throw an exception.");
		});
	}

	// Test if the appointment description is null
	@Test
	@DisplayName("Appointment description is null")
	void testAppointmentDescriptionIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("123456", new Date(), null);
		});
	}

	// Test setting new date
	@Test
	@DisplayName("Setter function tests")
	void testSetDateAndDescription() {
		Date today = new Date();
		Date tomorrow = new Date(04/01/2023);
		Appointment appointment = new Appointment("123456", today, "example description");
		appointment.setDate(tomorrow);
		appointment.setDescription("new example description");
		assertTrue(appointment.getDate().equals(tomorrow));
		assertTrue(appointment.getDescription().equals("new example description"));
	}
}