package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import Appointment.AppointmentService;
import Appointment.Appointment;

import java.util.Date;

public class AppointmentServiceTest {
	
	// test of creating an appointment class 
	@Test
	@DisplayName("Test of creating an appointment class")
	void testAppointmentClass() {
		AppointmentService appointmentService = new AppointmentService();
		Appointment appointment = new Appointment("123456", new Date(), "example description");
		assertFalse(appointmentService == null);
		assertFalse(appointment == null);
	}
	
	// test of creating an appointment
	@Test
	@DisplayName("Test of adding an appointment")
	void testAddAppointment() {
		AppointmentService appointmentService = new AppointmentService();
		Appointment appointment = new Appointment("123456", new Date(), "example description");
		appointmentService.addAppointment(appointment);
		assertTrue(appointmentService.getAppointments().containsValue(appointment));
	}
	
	// test of deleting an appointment 
	@Test
	@DisplayName("Test of deleting an appointment")
	void testDeleteAppointment() {
		AppointmentService appointmentService = new AppointmentService();
		Appointment appointment2 = new Appointment("654321", new Date(), "example description2");
		appointmentService.addAppointment(appointment2);
		appointmentService.deleteAppointment("654321");
		assertFalse(appointmentService.getAppointments().containsValue(appointment2));
	}
	
	
	// test of updating an appointment 
	@Test
	@DisplayName("Test of updating an appointment")
	void testUpdateAppointment() {
		AppointmentService appointmentService = new AppointmentService();
		Appointment appointment3 = new Appointment("987654321", new Date(), "example description3");		
		appointmentService.addAppointment(appointment3);
		assertTrue(appointmentService.getAppointments().containsValue(appointment3));
		assertTrue(appointment3.getDescription().equals("example description3"));
		appointmentService.updateAppointment("987654321", new Date(), "new example description3");
		assertTrue(appointmentService.getAppointments().containsValue(appointment3));
		assertFalse(appointment3.getDescription().equals("example description3"));
	}
}