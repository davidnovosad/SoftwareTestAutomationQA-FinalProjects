package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import Task.Task;
import Task.TaskService;

class TaskServiceTest {
	private TaskService testTaskService;


	//setting up new TaskServices for testing purposes
	@BeforeEach
	void setUp() {
		testTaskService = new TaskService();
		testTaskService.addTask(new Task("1", "name1", "description1"));
		testTaskService.addTask(new Task("2", "name2", "description2"));
		testTaskService.addTask(new Task("3", "name3", "description3"));
	}


	//Test to add a new task
	@Test
	@DisplayName("Test adding a new task")
	void testAddTask(){
		assertAll(
			() -> assertTrue(testTaskService.addTask(new Task("4", "name4", "description4"))),
			() -> assertTrue(testTaskService.getTasks().size() == 4)
		);
	}
	
	//Test to add an already existing task
	@Test
	@DisplayName("Test adding a task that is already added")
	void testAddTaskThatAlreadyExists() {
		assertAll(
			() -> assertFalse(testTaskService.addTask(new Task("1", "name1", "description1"))),
			() -> assertTrue(testTaskService.getTasks().size() == 3)
		);
	}


	//Test deleting a task with a correct ID
	@Test
	@DisplayName("Test deleting a task with a correct ID")
	void testDeleteTaskWithId() {
		assertAll(
			() -> assertTrue(testTaskService.deleteContact("3")),
			() -> assertTrue(testTaskService.getTasks().size() == 2)
		);
	}


	//Tests deleting a task with an incorrect ID
	@Test
	@DisplayName("Test deleting a task with an incorrect ID")
	void testDeleteTasktWithWrongId() {
		assertAll(
			() -> assertFalse(testTaskService.deleteContact("12")),
			() -> assertTrue(testTaskService.getTasks().size() == 3)
		);
	}


	//Test to update a task name with a correct ID
	@Test
	@DisplayName("Test updating a task name with a correct ID")
	void testUpdateNameWithId() {
		assertAll(
			() -> assertTrue(testTaskService.updateName("1", "new name1")),
			() -> assertTrue(testTaskService.getTasks().get(0).getName() == "new name1")
		);
	}


	//Test to update task name with an incorrect ID
	@Test
	@DisplayName("Test updating a task name with an incorrect ID")
	void testUpdateNameWithWrongId() {
		assertFalse(testTaskService.updateName("12", "new name1"));
	}
	

	//Test to update task name with correct ID but incorrect task name
	@Test
	@DisplayName("Test updating a task name with a correct ID but incorrect name")
	void testUpdateNameWithWrongName() {
		assertThrows(IllegalArgumentException.class, () -> testTaskService.updateName("2", null));
	}
	

	//Test to update task desc. with correct ID
	@Test
	@DisplayName("Test updating a task desc. with a correct ID")
	void testUpdateDescriptionWithCorrectId() {
		assertAll(
			() -> assertTrue(testTaskService.updateDescription("2", "new description2")),
			() -> assertTrue(testTaskService.getTasks().get(1).getDescription() == "new description2")
		);
	}
	

	//Test to update task desc. with wrong ID
	@Test
	@DisplayName("Test updating a task desc. with a wrong ID")
	void testUpdateDescriptionWithWrongId() {
		assertFalse(testTaskService.updateName("12", "new description12"));
	}
	

	//Test to update task desc. with correct ID but wrong desc.
	@Test
	@DisplayName("Test updating a task desc. with a correct ID but incorrect description")
	void testUpdateDescriptionWithInvalidDescription() {
		assertThrows(IllegalArgumentException.class, () -> testTaskService.updateDescription("2", null));
	}
}