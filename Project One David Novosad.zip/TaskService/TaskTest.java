package Test;

import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import Task.Task;

class TaskTest {

	// Test of getter functions
	@Test
	@DisplayName("Test of Getter functions")
	void testGetters() {
		Task task = new Task("123456", "task name", "task description");
		assertTrue(task.getTask_Id().equals("123456"));
		assertTrue(task.getName().equals("task name"));
		assertTrue(task.getDescription().equals("task description"));
	}

	// Tests creating a task with null/empty task ID
	@Test
	@DisplayName("Task ID is Null")
	void testTaskWithNullId() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task(null, "task name", "task description");
		});

	}

	// Tests creating a task with task ID longer than 10 characters
	@Test
	@DisplayName("Task ID is too long (more than 10 characters")
	void testTaskWithTooLongId() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("123456789101112", "task name", "task description");
		});

	}

	// Tests creating a task with null name.
	@Test
	@DisplayName("Task name is Null")
	void testTaskWithNullName() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("123456", null, "task description");
		});
	}

	// Tests creating a task with invalid length argument for name.
	@Test
	@DisplayName("Task name is too long (more than 20 characters)")
	void testTaskWithTooLongName() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("123456", "task name has more than 20 characters", "task description");
		});
	}

	// Tests creating a task with invalid argument for description.
	@Test
	@DisplayName("Task description is Null")
	void testTaskWithNullDescription() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("123456", "task name", null);
		});
	}

	// Tests creating a task with invalid length argument for description.
	@Test
	@DisplayName("Task description is too long (more than 50 characters)")
	void testTaskWithTooLongDescription() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("123456", "task name",
					"task description is very long having more than 50 characters an therefore an exception is thrown");
		});
	}
}