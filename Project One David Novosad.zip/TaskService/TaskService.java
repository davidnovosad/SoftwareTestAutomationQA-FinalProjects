package Task;

import java.util.ArrayList;
import java.util.List;

public class TaskService {
	private final List<Task> tasksList;


	//Default constructor initializing a new array list.
	public TaskService() {
		this.tasksList = new ArrayList<Task>();
	}


	//Getter function for the tasks array list.
	public List<Task> getTasks() {
		return tasksList;
	}

	//Method used to add a task to the initialized list.
	public boolean addTask(final Task newTask) {
		// select boolean existingTask to be default false
		boolean existingTask = false;
		for (Task task : tasksList) {
			if (newTask.getTask_Id() == task.getTask_Id()) {
				existingTask = true;
			}
		}

		// if the task does not exist yet add it to the list
		if (!existingTask) {
			this.tasksList.add(newTask);
			// if the task was added into the list return boolean true.
			return true;
		} else {
			// else the task exists, return boolean false.
			return false;
		}
	}


	//Method used to delete a task in the list if the ID of the task matches.
	public boolean deleteContact(final String idOfTask) {
		return this.tasksList.removeIf(task -> (task.getTask_Id() == idOfTask));
	}


	//Method responsible for updating the task name if ID of the task matches.
	public boolean updateName(final String idOfTask, final String nameOfTask) {
		//select boolean updateSucessful to be default as false.
		boolean updateSucessful = false;
		for (Task task : tasksList) {
			if (task.getTask_Id() == idOfTask) {
				task.setName(nameOfTask);
				//task name was updated
				updateSucessful = true;
			}
		}
		return updateSucessful;
	}


	//Method responsible for updating the task description if ID of the task matches
	public boolean updateDescription(final String idOfTask, final String descriptionOfTask) {
		//select boolean updateSucessful to be default as false.
		boolean updateSucessful = false;
		for (Task task : tasksList) {
			if (task.getTask_Id() == idOfTask) {
				task.setDescription(descriptionOfTask);
				//task name was updated
				updateSucessful = true;
			}
		}
		return updateSucessful;
	}
}