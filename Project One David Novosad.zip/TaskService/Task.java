package Task;

public class Task {
	private String task_Id;
	private String name;
	private String description;
	
	
	//default constructor.
	private Task() {
	}
	

	//constructor responsible for creating a task.
	public Task(final String task_Id, final String name, final String description) {
		this();
		
		// if/ else statements to confirm all the requirements are met
		if (task_Id == null || task_Id.isEmpty()) {
			throw new IllegalArgumentException("ID of the task cannot be empty.");
		} else if (task_Id.length() > 10) {
			throw new IllegalArgumentException("ID of the task cannot be longer than 10 characters.");
		} else {
			this.task_Id = task_Id;
		}
		
		// Calls methods to sets the rest of the values and validate the input.
		setName(name);
		setDescription(description);
	}

	//Getter function for task_Id variable.
	public String getTask_Id() {
		return task_Id;
	}
	
	//Getter function for name variable.

	public String getName() {
		return name;
	}


	//Setter function for name variable.

	public void setName(final String name) {
		// Check name meets requirements before setting
		if (name == null || name.isEmpty()) {
			throw new IllegalArgumentException("name must have a value.");
		} else if (name.length() > 20) {
			throw new IllegalArgumentException("name cannot be longer than 20 characters.");
		} else {
			this.name = name;
		}
	}

	//Getter function for description variable.

	public String getDescription() {
		return description;
	}


	//Setter function for description variable.
	public void setDescription(final String description) {
		// Check description meets requirements before setting
		if (description == null || description.isBlank()) {
			throw new IllegalArgumentException("description must have a value.");
		} else if (description.length() > 50) {
			throw new IllegalArgumentException("description cannot be longer than 50 characters.");
		} else {
			this.description = description;
		}
	}
}