package contactService;

import java.util.Random;
import java.util.Vector;

public class ContactService {

	private Vector<Contact> contactsInformation = new Vector<Contact>();

	// Getter for the vector
	public Vector<Contact> getContactsInformation() {
		return contactsInformation;
	}

	public void addContact(String contactId, String firstName, String lastName, String phone, String address) {
		Contact newContact = new Contact(contactId, firstName, lastName, phone, address);

		contactsInformation.add(newContact);
	}

	// Get all contact's information from a vector and display it
	public void displayContacts() {
		for (int i = 0; i < contactsInformation.size(); i++) {
			System.out.println("ID: " + getContactsInformation().elementAt(i).getContactId() + " Name: "
					+ getContactsInformation().elementAt(i).getFirstName() + " "
					+ getContactsInformation().elementAt(i).getLastName() + " Phone: "
					+ getContactsInformation().elementAt(i).getPhoneNum() + " Address: "
					+ getContactsInformation().elementAt(i).getAddress());
		}
		if (contactsInformation.isEmpty()) {
			System.out.println("No contacts to display");
		}
	}

	public void deleteContact(String contactId) {
		// Check if contactId is accurate
		if (contactId == null || contactId.length() > 10) {
			throw new IllegalArgumentException("Invalid ID");

		}

		// Check if contact list is empty
		if (contactsInformation.isEmpty()) {
			throw new IllegalArgumentException("No Contacts To Delete");
		}

		int index = -1;
		for (Contact i : contactsInformation) {
			if (i.getContactId() == contactId) {
				index = contactsInformation.indexOf(i);
			}

		}
		if (index == -1) {
			System.out.println("Contact Not Found.");
			return;
		} else {
			contactsInformation.remove(index);
			System.out.println("Contact Removed Successfully");
		}

	}

	private void deleteOldContact(Contact contact) {
		contactsInformation.remove(contact);
	}

	public void addUpdatedContact(Contact contact) {
		contactsInformation.add(contact);
	}

	public void updateContact(String contactId, String updateInformation, int input) {
		// Check if contact info is accurate
		if (contactId == null || contactId.length() > 10 || updateInformation == null || input < 0) {
			throw new IllegalArgumentException("Invalid Input or ID");
		}

		// Check if contact list is empty
		if (contactsInformation.isEmpty()) {
			throw new IllegalArgumentException("No Contacts To Update");
		}

		int index = -1;
		for (Contact i : contactsInformation) {
			if (i.getContactId() == contactId) {
				index = contactsInformation.indexOf(i);
			}

		}
		if (index == -1) {
			System.out.println("Contact Not Found");
			return;
		}

		Contact updateContact = contactsInformation.get(index);

		switch (input) {
		case 1: {
			updateContact.setFirstName(updateInformation);
			break;
		}
		case 2: {
			updateContact.setLastName(updateInformation);
			break;
		}
		case 3: {
			updateContact.setPhoneNum(updateInformation);
			break;
		}
		case 4: {
			updateContact.setAddress(updateInformation);
			break;
		}
		default: {
			System.out.println("Contact Not Updated due to an Invalid Input");
			break;
		}
		}

		deleteOldContact(contactsInformation.elementAt(index));
		addUpdatedContact(updateContact);

	}

	public String IdGenerator() {
		int min = 1;
		int max = 999999999;

		// Generates a random task ID between 1 and 999999999
		Random Id = new Random();
		int newId = Id.nextInt(max - min + 1) + min;
		String randomId = Integer.toString(newId);

		// Generate new ID if one already exists in list
		for (Contact i : contactsInformation) {
			while (i.getContactId() == randomId) {
				newId = Id.nextInt(max - min + 1) + min;
				randomId = Integer.toString(newId);
			}
		}

		return randomId;
	}
}