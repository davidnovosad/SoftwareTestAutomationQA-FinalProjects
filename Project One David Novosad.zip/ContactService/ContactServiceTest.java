package test;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import contactService.ContactService;

class ContactServiceTest {

	@Test
	@DisplayName("Adding a New Contact")
	void testAddContact() {

		// Creating a new contact
		ContactService contactService = new ContactService();
		String randomId = contactService.IdGenerator();
		// Checking if the list is empty
		contactService.displayContacts();
		// Adding the new contact into the list
		contactService.addContact(randomId, "David", "Novosad", "1234567890", "111 Example St.");
		// Check if the list is empty and if the contact was added
		assertTrue(!contactService.getContactsInformation().isEmpty());
		assertTrue(contactService.getContactsInformation().elementAt(0).getContactId().equals(randomId));
		// Display the list of contacts
		contactService.displayContacts();
	}

	@Test
	@DisplayName("Testing Unique IDs")
	void testUniqueID() {

		// Create a new contact list
		ContactService contactService = new ContactService();
		// generate random IDS
		String randomId1 = contactService.IdGenerator();
		String randomId2 = contactService.IdGenerator();
		String randomId3 = contactService.IdGenerator();
		// Add the new contacts to list
		contactService.addContact(randomId1, "David", "Novosad", "1234567890", "111 Example St.");
		contactService.addContact(randomId2, "Magnus", "Carlsen", "0987654321", "222 New Example Rd.");
		contactService.addContact(randomId3, "Peter", "Peterson", "1122334455", "333 Newer Example Blvd.");
		// Display contacts to show IDs
		contactService.displayContacts();
		// Check if IDs are the same
		assertTrue(
				contactService.getContactsInformation().elementAt(0).getContactId() != contactService.getContactsInformation().elementAt(1).getContactId());
		assertTrue(
				contactService.getContactsInformation().elementAt(1).getContactId() != contactService.getContactsInformation().elementAt(2).getContactId());
		assertTrue(
				contactService.getContactsInformation().elementAt(0).getContactId() != contactService.getContactsInformation().elementAt(2).getContactId());
	}

	@Test
	@DisplayName("Delete Contact by its Id")
	void testDeleteContact() {
		ContactService contactService = new ContactService();
		// Generate random IDs
		String randomId1 = contactService.IdGenerator();
		String randomId2 = contactService.IdGenerator();
		String randomId3 = contactService.IdGenerator();
		// Removing a contact before adding contacts
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contactService.deleteContact(randomId1);
		});

		// Add new contacts to list
		contactService.addContact(randomId1, "David", "Novosad", "1234567890", "111 Example St.");
		contactService.addContact(randomId2, "Magnus", "Carlsen", "0987654321", "222 New Example Rd.");
		contactService.addContact(randomId3, "Peter", "Peterson", "1122334455", "333 Newer Example Blvd.");
		// Delete a contact Id that does not exist
		contactService.deleteContact("12345");
		// Remove id that is too long
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contactService.deleteContact("12345678901");
		});
		// Try to remove id that is null
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contactService.deleteContact(null);
		});
		// display the list of contacts, it is not empty
		// contact was not removed because the id does not exist
		contactService.displayContacts();
		assertTrue(!contactService.getContactsInformation().isEmpty());
		// deleting last contact in list and display list
		contactService.deleteContact(randomId3);
		contactService.displayContacts();
		// removing all the other contacts
		contactService.deleteContact(randomId1);
		contactService.deleteContact(randomId2);
		// display the list as it should be empty
		contactService.displayContacts();
		assertTrue(contactService.getContactsInformation().isEmpty());

	}

	@Test
	@DisplayName("Updating the Contact With Invalid Input from user")
	void testUpdateContactWithErrors() {
		ContactService contactService = new ContactService();
		String randomID = contactService.IdGenerator();
		// Contact list is empty
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contactService.updateContact(randomID, "Susan", 1);
		});

		// Creating a new contact and adding it to the list
		contactService.addContact(randomID, "David", "Novosad", "1234567890", "111 Example St.");
		// check if the list is empty after adding the contact
		assertTrue(!contactService.getContactsInformation().isEmpty());

		// contact id is too long
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contactService.updateContact("1234567890123", "Susan", 1);
		});
		// contact id is null
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contactService.updateContact(null, "Susan", 1);
		});
		// Name is null
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contactService.updateContact(randomID, null, 1);
		});
		// user input is less than zero
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contactService.updateContact(randomID, "Susan", -1);
		});
		// the inputed first name is too long
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contactService.updateContact(randomID, "DavidDavidNovosad", 1);
		});
		// the inputed last name is too long
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contactService.updateContact(randomID, "DavidDavidNovosad", 2);
		});
		// the inputed phone number is too long
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contactService.updateContact(randomID, "1234567890123", 3);
		});
		// the inputed phone number is too short
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contactService.updateContact(randomID, "1234", 3);
		});
		// the inputed address is too long
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contactService.updateContact(randomID, "1234567890 VeryLongStreetAddress Rd.", 4);
		});
		// inputed first name is equal to null
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contactService.updateContact(randomID, null, 1);
		});
		// inputed last name is equal to null
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contactService.updateContact(randomID, null, 2);
		});
		// inputed phone number is equal to null
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contactService.updateContact(randomID, null, 3);
		});
		// inputed address is equal to null
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contactService.updateContact(randomID, null, 4);
		});

		// Display "Contact Not Found or Contact does not Exist" - Wrong ID inputed
		contactService.updateContact("1234567890", "Mark", 1);

		// Print "Contact Not Updated due to an Invalid Input"default use case
		contactService.updateContact(randomID, "Mark", 999);

	}

	@Test
	@DisplayName("Updating Contact Information With Valid Input")
	void testUpdateContactWithCorrectInput() {
		ContactService contactService = new ContactService();
		String randomId = contactService.IdGenerator();
		contactService.addContact(randomId, "David", "Novosad", "1234567890", "111 Example St.");
		assertTrue(!contactService.getContactsInformation().isEmpty());
		// Display the list with original contacts
		contactService.displayContacts();

		// Updating the contact's First Name
		contactService.updateContact(randomId, "Magnus", 1);
		assertTrue(contactService.getContactsInformation().elementAt(0).getFirstName().equals("Magnus"));
		// Updating the contact's Last Name
		contactService.updateContact(randomId, "Carlsen", 2);
		assertTrue(contactService.getContactsInformation().elementAt(0).getLastName().equals("Carlsen"));
		// Updating the contact's Phone Number
		contactService.updateContact(randomId, "0987654321", 3);
		assertTrue(contactService.getContactsInformation().elementAt(0).getPhoneNum().equals("0987654321"));
		// Updating the contact's Address
		contactService.updateContact(randomId, "222 New Example Rd.", 4);
		assertTrue(contactService.getContactsInformation().elementAt(0).getAddress().equals("222 New Example Rd."));

		// Check if the first and last names were updated
		assertTrue((contactService.getContactsInformation().elementAt(0).getFirstName().equals("Magnus"))
				&& (contactService.getContactsInformation().elementAt(0).getLastName().equals("Carlsen")));
		
		// Display contact with the updated information
		contactService.displayContacts();
	}

}