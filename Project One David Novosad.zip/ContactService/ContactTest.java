package test;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import contactService.Contact;

class ContactTest {

	@Test
	@DisplayName("Contact ID is Null")
	void testcontactIdIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "David", "Novosad", "1234567890", "111 Example St.");
		});

	}

	@Test
	@DisplayName("Contact First Name is Null")
	void testFirstNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123456", null, "Novosad", "1234567890", "111 Example St.");
		});

	}

	@Test
	@DisplayName("Contact Last Name is Null")
	void testLastNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123456", "David", null, "1234567890", "111 Example St.");
		});

	}

	@Test
	@DisplayName("Contact Phone Number is Null")
	void testPhoneNumNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123456", "David", "Novosad", null, "111 Example St.");
		});

	}

	@Test
	@DisplayName("Contact Address is Null")
	void testAddressNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123456", "David", "Novosad", "1234567890", null);
		});

	}

	@Test
	@DisplayName("Setting Attributes to Null")
	void testAllNullAttributes() {
		Contact contact = new Contact("123456", "David", "Novosad", "1234567890", "111 Example St.");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setFirstName(null);
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setLastName(null);
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setPhoneNum(null);
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setAddress(null);
		});
	}

	@Test
	@DisplayName("Getter functions")
	void testGetters() {
		Contact contact = new Contact("123456", "David", "Novosad", "1234567890", "111 Example St.");
		assertTrue(contact.getContactId().equals("123456"));
		assertTrue(contact.getFirstName().equals("David"));
		assertTrue(contact.getLastName().equals("Novosad"));
		assertTrue(contact.getPhoneNum().equals("1234567890"));
		assertTrue(contact.getAddress().equals("111 Example St."));
	}

	@Test
	@DisplayName("Set New First Name")
	void testSetNewFirstName() {
		Contact contact = new Contact("123456", "David", "Novosad", "1234567890", "111 Example St.");
		contact.setFirstName("Magnus");
		assertTrue(contact.getFirstName().equals("Magnus"));
	}

	@Test
	@DisplayName("Set New Last Name")
	void testSetNewLastName() {
		Contact contact = new Contact("123456", "David", "Novosad", "1234567890", "111 Example St.");
		contact.setLastName("Carlsen");
		assertTrue(contact.getLastName().equals("Carlsen"));
	}

	@Test
	@DisplayName("Set New Phone Number")
	void testSetNewPhoneNumber() {
		Contact contact = new Contact("123456", "David", "Novosad", "1234567890", "111 Example St.");
		contact.setPhoneNum("0987654321");
		assertTrue(contact.getPhoneNum().equals("0987654321"));
	}

	@Test
	@DisplayName("Set New Address")
	void testSetNewAddress() {
		Contact contact = new Contact("123456", "David", "Novosad", "1234567890", "111 Example St.");
		contact.setAddress("222 New Example Rd.");
		assertTrue(contact.getAddress().equals("222 New Example Rd."));
	}

	@Test
	@DisplayName("Attributes Too Big")
	void testSetMoreThanAllowedCharacters() {
		Contact contact = new Contact("123456", "David", "Novosad", "1234567890", "111 Example St.");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setFirstName("DavidDavidDavid");
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setLastName("NovosadNovosad");
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setPhoneNum("12345678901");
		});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setAddress("1234567890 Verylongstreetname St.");
		});
	}

	@Test
	@DisplayName("ID Too Long")
	void testLongID() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678901", "David", "Novosad", "1234567890", "111 Example St.");
		});
	}

	@Test
	@DisplayName("Phone Number Too Small")
	void testPhoneLessThanTen() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123456", "David", "Novosad", "1234", "111 Example St.");
		});
	}

}
